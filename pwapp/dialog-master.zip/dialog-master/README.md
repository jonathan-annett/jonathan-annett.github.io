# dialog

A javascript dialog plugin using ES6.

Open index.html to show demo.
