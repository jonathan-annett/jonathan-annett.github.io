export interface ShellElement {
    toString(): string;
}
