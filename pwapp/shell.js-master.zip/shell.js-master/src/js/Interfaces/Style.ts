// Available styles
export enum Style {
    DEFAULT = "default",
    OSX = "osx",
    UBUNTU = "ubuntu",
    WINDOWS = "windows"
}
