export interface CommandParams {
    counter?: number;
    empty?: boolean;
    command?: string;
    output?: boolean;
}
