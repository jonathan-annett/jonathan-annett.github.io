// Available themes
export enum Theme {
    DARK = "dark",
    LIGHT = "light"
}
