import {DefaultBuilder} from "./";

export class UbuntuBuilder extends DefaultBuilder {
}
