function test(callback) {
    'aaaaaaaaaaaaaaaa';
    callback(err, data);
    callback(err, data);
}
