var c = [1, 2];
for (var a, b in c) {
    console.log(a, c[a]);
}
