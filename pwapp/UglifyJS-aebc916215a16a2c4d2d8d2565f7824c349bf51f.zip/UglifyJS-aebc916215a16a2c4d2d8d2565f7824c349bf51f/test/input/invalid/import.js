{
    import A from "B";
}
