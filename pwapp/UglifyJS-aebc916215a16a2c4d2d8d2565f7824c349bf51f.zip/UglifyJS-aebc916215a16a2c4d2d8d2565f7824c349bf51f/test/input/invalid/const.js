function f() {
    const a;
}
