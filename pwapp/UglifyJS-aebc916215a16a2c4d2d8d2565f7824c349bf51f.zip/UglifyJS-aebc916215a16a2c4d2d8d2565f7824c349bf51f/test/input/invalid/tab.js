		foo(	xyz, 0abc);
