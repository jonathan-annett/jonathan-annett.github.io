console.log(2 || (Math.random() /= 2));
