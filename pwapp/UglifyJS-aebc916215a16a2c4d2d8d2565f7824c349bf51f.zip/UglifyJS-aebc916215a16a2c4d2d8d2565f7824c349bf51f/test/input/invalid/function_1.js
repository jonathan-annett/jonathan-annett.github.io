function f(arguments) {
}

function g(arguments) {
    "use strict";
}
