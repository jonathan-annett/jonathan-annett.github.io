if(typeof require !== "undefined") {
    window.nodeRequire = require;
    require = null;
}
