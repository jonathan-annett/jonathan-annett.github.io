Tips and Tricks
===============

Navigate between projects
-------------------------
Press `Command-Shift-O`/`Ctrl-Shift-O` in any Zed editor window to jump to the project list window. In there, type to filter the projects and navigate between them using `Up` or `Shift-Tab` and `Down` or `Tab`. Press `Enter` to open the project.

Navigate between windows
-------------------------
Press `Command-Shift-P`/`Ctrl-Shift-P` to open `Window:List` list of windows and quickly jump between open Zed windows.
