The Zed Sandbox
===============

Coming soon, for now check this for a list of all supported APIs:

    https://github.com/zedapp/zed/tree/master/app/js/sandbox/interface/zed