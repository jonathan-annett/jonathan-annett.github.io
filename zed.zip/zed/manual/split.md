Split-view Editing
==================
Keys (replace `Command` with `Ctrl` on non-Mac machines):

* `Command-1`: No splits
* `Command-2`: Two vertical splits, press repeatedly to switch between 50%/50%,
  33/66% and 66%/33%
* `Command-3`: Three vertical splits
* `Command-P`: Two vertical splits where the right previews the one at the left
  (supported for some languages, e.g. Markdown, HTML and CoffeeScript)
* `Command-Shift-1`: Move currently focused split to window position 1
* `Command-Shift-2`: Move currently focused split to window position 2
* `Command-Shift-3`: Move currently focused split to window position 3
